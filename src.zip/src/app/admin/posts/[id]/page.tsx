
"use client";

import { useParams } from 'next/navigation';
import { PostEditor } from '@/components/admin/blog/PostEditor';
import { ErsAdminHeader } from '@/components/admin/ErsAdminHeader';
import { withAuth } from '@/context/AuthContext';

function EditPostPage() {
  const params = useParams();
  const { id } = params;

  return (
    <div className="min-h-screen bg-background text-foreground">
      <ErsAdminHeader />
      <main className="container mx-auto px-4 py-8">
        <PostEditor postId={id as string} />
      </main>
    </div>
  );
}

export default withAuth(EditPostPage);
