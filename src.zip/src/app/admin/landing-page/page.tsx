
"use client";

import { ErsAdminHeader } from '@/components/admin/ErsAdminHeader';
import { LandingPageSettings } from '@/components/admin/LandingPageSettings';
import { withAuth } from '@/context/AuthContext';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';

function LandingPageSettingsPage() {
  const router = useRouter();

  // This is a temporary redirect until a proper /admin page is created.
  useEffect(() => {
    router.replace('/admin/landing-page');
  }, [router]);


  return (
    <div className="min-h-screen bg-background text-foreground">
      <ErsAdminHeader />
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold tracking-tight mb-6">Pengaturan Landing Page</h2>
          <LandingPageSettings />
        </div>
      </main>
    </div>
  );
}

// We rename the component to avoid confusion and export it with the authentication wrapper.
const AuthenticatedLandingPageSettingsPage = withAuth(LandingPageSettingsPage);

// We define a new default export for the `/admin` route.
export default function AdminPage() {
  const router = useRouter();

  useEffect(() => {
    router.replace('/admin/landing-page');
  }, [router]);
  
  return (
     <div className="flex h-screen items-center justify-center">
        <div>Mengarahkan...</div>
    </div>
  );
}

// We need a named export for the actual page content at /admin/landing-page
export { AuthenticatedLandingPageSettingsPage };
