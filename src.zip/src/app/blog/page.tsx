
import { collection, getDocs, query, where, orderBy } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import type { Post } from '@/lib/types';
import Link from 'next/link';
import Image from 'next/image';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';
import { id } from 'date-fns/locale';
import { ArrowRight } from 'lucide-react';

async function getPosts(): Promise<Post[]> {
  const postsCollection = collection(db, 'posts');
  // We query only by status, and sort later in the code to avoid needing a composite index immediately.
  const q = query(postsCollection, where('status', '==', 'published'));
  const querySnapshot = await getDocs(q);
  
  const posts = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Post));

  // Sort by createdAt date in descending order (newest first)
  posts.sort((a, b) => {
    const dateA = a.createdAt?.toDate() || 0;
    const dateB = b.createdAt?.toDate() || 0;
    return dateB.valueOf() - dateA.valueOf();
  });

  return posts;
}

// Replicated on server-side to avoid client/server mismatch error.
const transformGoogleDriveUrl = (url: string): string => {
    if (!url || !url.includes('drive.google.com')) {
        return url;
    }
    const match = url.match(/file\/d\/([^/]+)/);
    if (match && match[1]) {
        return `https://drive.google.com/uc?export=view&id=${match[1]}`;
    }
    return url;
};

const getExcerpt = (content: string, length = 150) => {
    if (!content) return '';
    const strippedContent = content.replace(/(\r\n|\n|\r|#|!\[.*\]\(.*\))/gm, " ").trim();
    if (strippedContent.length <= length) return strippedContent;
    return `${strippedContent.substring(0, length)}...`;
};


export default async function BlogPage() {
  const posts = await getPosts();

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl">VELL Blog</h1>
        <p className="mt-4 max-w-xl mx-auto text-muted-foreground">
          Artikel, panduan, dan pembaruan terbaru dari tim VELL.
        </p>
      </div>

      {posts.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {posts.map(post => {
            const imageUrl = post.featuredImageUrl ? transformGoogleDriveUrl(post.featuredImageUrl) : "https://picsum.photos/seed/blog-post/600/400";
            return (
              <Link href={`/blog/${post.slug}`} key={post.id} className="group">
                <article className="h-full flex flex-col rounded-lg border bg-card text-card-foreground shadow-sm overflow-hidden transition-all hover:shadow-lg">
                  <div className="relative h-56 w-full">
                    <Image
                      src={imageUrl}
                      alt={post.title}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="p-6 flex flex-col flex-grow">
                    <h2 className="text-2xl font-semibold mb-2 group-hover:text-primary transition-colors">{post.title}</h2>
                    <div className="text-sm text-muted-foreground mb-4">
                      <span>{post.authorName}</span> &bull; <span>{post.createdAt ? format(post.createdAt.toDate(), 'd MMM yyyy', { locale: id }) : ''}</span>
                    </div>
                    <p className="text-muted-foreground flex-grow">{getExcerpt(post.content)}</p>
                    <div className="mt-6 flex justify-end">
                       <div className="flex items-center text-primary font-semibold">
                          Baca Selengkapnya <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                        </div>
                    </div>
                  </div>
                </article>
              </Link>
            )
          })}
        </div>
      ) : (
        <div className="text-center py-16">
          <h2 className="text-2xl font-semibold">Belum Ada Postingan</h2>
          <p className="mt-2 text-muted-foreground">Saat ini belum ada postingan yang diterbitkan. Silakan periksa kembali nanti.</p>
        </div>
      )}
    </div>
  );
}
