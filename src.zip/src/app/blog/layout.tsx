
import { ErsAdminHeader } from '@/components/admin/ErsAdminHeader';
import type { Metadata } from 'next';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Mountain } from 'lucide-react';
import Image from 'next/image';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import type { LandingPageContent, CompanyInfo } from '@/lib/types';


async function getContent(): Promise<{ content: LandingPageContent, companyInfo: CompanyInfo }> {
  try {
    const contentSnap = await getDoc(doc(db, "settings", "landingPage"));
    const companySnap = await getDoc(doc(db, "settings", "companyInfo"));
    
    const content = contentSnap.exists() ? contentSnap.data() as LandingPageContent : { brandName: "VELL" };
    const companyInfo = companySnap.exists() ? companySnap.data() as CompanyInfo : { companyName: "VELL" };

    return { content, companyInfo };
  } catch (error) {
    console.error("Error fetching header content:", error);
    return { 
        content: { brandName: "VELL" }, 
        companyInfo: { companyName: 'VELL' }
    };
  }
}

// Replicated on server-side to avoid client/server mismatch error.
const transformGoogleDriveUrl = (url: string): string => {
    if (!url || !url.includes('drive.google.com')) {
        return url;
    }
    const match = url.match(/file\/d\/([^/]+)/);
    if (match && match[1]) {
        return `https://drive.google.com/uc?export=view&id=${match[1]}`;
    }
    return url;
};


export const metadata: Metadata = {
  title: 'Blog | VELL',
  description: 'Artikel, berita, dan pembaruan dari VELL.',
};

export default async function BlogLayout({
  children,
}: {
  children: React.ReactNode;
}) {
    const { content, companyInfo } = await getContent();
    const ersLogoUrl = companyInfo.ersLogoUrl ? transformGoogleDriveUrl(companyInfo.ersLogoUrl) : null;

  return (
    <div className="flex flex-col min-h-screen bg-background">
      <header className="px-4 lg:px-6 h-16 flex items-center bg-background border-b sticky top-0 z-50">
        <Link href="/" className="flex items-center justify-center gap-2" prefetch={false}>
            {ersLogoUrl ? (
                <Image src={ersLogoUrl} alt="VELL Logo" width={24} height={24} className="h-6 w-6 object-contain" />
            ) : (
                <Mountain className="h-6 w-6 text-primary" />
            )}
            <span className="text-xl font-bold tracking-tight text-primary">{content.brandName || "VELL"}</span>
        </Link>
        <nav className="ml-auto flex items-center gap-4 sm:gap-6">
          <Link href="/#features" className="text-sm font-medium text-muted-foreground transition-colors hover:text-primary" prefetch={false}>
            Fitur
          </Link>
          <Link href="/#portfolio" className="text-sm font-medium text-muted-foreground transition-colors hover:text-primary" prefetch={false}>
            Portofolio
          </Link>
           <Link href="/paket" className="text-sm font-medium text-muted-foreground transition-colors hover:text-primary" prefetch={false}>
            Paket
          </Link>
          <Link href="/blog" className="text-sm font-bold text-primary" prefetch={false}>
            Blog
          </Link>
          <Link href="/#kontak" className="text-sm font-medium text-muted-foreground transition-colors hover:text-primary" prefetch={false}>
            Kontak
          </Link>
          <Link href="/admin/login" prefetch={false}>
             <Button>Login</Button>
          </Link>
        </nav>
      </header>
      <main className="flex-1">
        {children}
      </main>
       <footer className="flex flex-col gap-2 sm:flex-row py-6 w-full shrink-0 items-center px-4 md:px-6 border-t">
        <p className="text-xs text-muted-foreground">&copy; 2024 {content.brandName || "VELL"}. Semua Hak Cipta Dilindungi.</p>
        <nav className="sm:ml-auto flex gap-4 sm:gap-6">
          <Link href="#" className="text-xs hover:underline underline-offset-4" prefetch={false}>
            Syarat & Ketentuan
          </Link>
          <Link href="#" className="text-xs hover:underline underline-offset-4" prefetch={false}>
            Kebijakan Privasi
          </Link>
        </nav>
      </footer>
    </div>
  );
}
