
import { collection, getDocs, query, where } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import type { Post } from '@/lib/types';
import { notFound } from 'next/navigation';
import Image from 'next/image';
import { format } from 'date-fns';
import { id } from 'date-fns/locale';
import { LikeButton } from '@/components/blog/LikeButton';

// This library is not available, so we will use a simple regex replacement for markdown.
// import { unified } from 'unified';
// import remarkParse from 'remark-parse';
// import remarkHtml from 'remark-html';

async function getPostBySlug(slug: string): Promise<Post | null> {
  const postsCollection = collection(db, 'posts');
  const q = query(postsCollection, where('slug', '==', slug), where('status', '==', 'published'));
  const querySnapshot = await getDocs(q);

  if (querySnapshot.empty) {
    return null;
  }
  const doc = querySnapshot.docs[0];
  return { id: doc.id, ...doc.data() } as Post;
}

// Replicated on server-side to avoid client/server mismatch error.
const transformGoogleDriveUrl = (url: string): string => {
    if (!url || !url.includes('drive.google.com')) {
        return url;
    }
    const match = url.match(/file\/d\/([^/]+)/);
    if (match && match[1]) {
        return `https://drive.google.com/uc?export=view&id=${match[1]}`;
    }
    return url;
};

// Basic markdown to HTML converter.
function markdownToHtml(markdown: string) {
    if (!markdown) return '';
    return markdown
        .replace(/^### (.*$)/gim, '<h3>$1</h3>')
        .replace(/^## (.*$)/gim, '<h2>$1</h2>')
        .replace(/^# (.*$)/gim, '<h1>$1</h1>')
        .replace(/^\> (.*$)/gim, '<blockquote>$1</blockquote>')
        .replace(/\*\*(.*)\*\*/gim, '<strong>$1</strong>')
        .replace(/\*(.*)\*/gim, '<em>$1</em>')
        .replace(/!\[(.*?)\]\((.*?)\)/gim, "<img alt='$1' src='$2' class='rounded-lg shadow-md my-4' />")
        .replace(/\[(.*?)\]\((.*?)\)/gim, "<a href='$2' class='text-primary hover:underline'>$1</a>")
        .replace(/\n$/gim, '<br />')
        .replace(/\n/gim, '<br />');
}


export default async function BlogPostPage({ params }: { params: { slug: string } }) {
  const post = await getPostBySlug(params.slug);

  if (!post) {
    notFound();
  }

  const imageUrl = post.featuredImageUrl ? transformGoogleDriveUrl(post.featuredImageUrl) : "https://picsum.photos/seed/blog-header/1200/600";
//   const processedContent = await unified().use(remarkParse).use(remarkHtml).process(post.content);
  const contentHtml = markdownToHtml(post.content);


  return (
    <article className="max-w-4xl mx-auto py-8 px-4">
        <header className="mb-8">
            <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none text-foreground mb-4">
                {post.title}
            </h1>
            <div className="flex items-center justify-between text-sm text-muted-foreground">
                <p>
                    Ditulis oleh {post.authorName} pada {post.createdAt ? format(post.createdAt.toDate(), 'd MMMM yyyy', { locale: id }) : ''}
                </p>
                <LikeButton postId={post.id} initialLikes={post.likes || 0} />
            </div>
        </header>

        <div className="w-full h-[30vh] md:h-[50vh] relative rounded-lg overflow-hidden shadow-lg mb-8">
            <Image
                src={imageUrl}
                alt={post.title}
                fill
                className="object-cover"
                priority
            />
        </div>

        <div className="prose prose-lg dark:prose-invert max-w-none mx-auto"
            dangerouslySetInnerHTML={{ __html: contentHtml }}
        />
    </article>
  );
}
