
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Check } from "lucide-react";

const pricingTiers = [
  {
    name: "Basic",
    price: "Rp 3.500.000",
    description: "Untuk memulai bisnis Anda dengan fitur esensial.",
    features: [
      "Sistem Kasir (POS)",
      "Manajemen Menu Digital",
      "Pemesanan via Kode QR",
      "Monitor Dapur & Pelayan",
      "Laporan Penjualan Dasar",
    ],
    cta: "Pilih Paket Basic"
  },
  {
    name: "Pro",
    price: "Rp 5.000.000",
    description: "Solusi lengkap untuk mengoptimalkan operasional.",
    isPopular: true,
    features: [
      "Semua fitur di paket Basic",
      "Manajemen Inventaris & Stok",
      "Manajemen Vendor & PO",
      "Analisis Food Cost",
      "Manajemen Akun & Peran",
      "Dukungan Prioritas",
    ],
    cta: "Pilih Paket Pro"
  },
  {
    name: "Enterprise",
    price: "Hubungi Kami",
    description: "Disesuaikan untuk kebutuhan unik bisnis skala besar.",
    features: [
      "Semua fitur di paket Pro",
      "Dukungan Multi-Cabang",
      "Kustomisasi Branding Penuh",
      "Integrasi Sistem Pihak Ketiga",
      "Dedicated Account Manager",
      "SLA (Service Level Agreement)",
    ],
    cta: "Hubungi Penjualan"
  }
];

export default function PaketPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl">Paket & Harga</h1>
        <p className="mt-4 max-w-xl mx-auto text-muted-foreground">
          Pilih paket yang paling sesuai untuk membawa bisnis F&B Anda ke level berikutnya.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-5xl mx-auto">
        {pricingTiers.map((tier) => (
          <Card key={tier.name} className={`flex flex-col ${tier.isPopular ? 'border-primary shadow-2xl' : ''}`}>
            {tier.isPopular && (
                <div className="bg-primary text-primary-foreground text-center py-1 font-semibold text-sm rounded-t-lg">Paling Populer</div>
            )}
            <CardHeader className="text-center">
              <CardTitle className="text-3xl">{tier.name}</CardTitle>
              <CardDescription className="min-h-[40px]">{tier.description}</CardDescription>
            </CardHeader>
            <CardContent className="flex-grow">
              <div className="text-center mb-6">
                <span className="text-4xl font-bold">{tier.price}</span>
                {tier.name !== 'Enterprise' && <span className="text-muted-foreground"> /sekali bayar</span>}
              </div>
              <ul className="space-y-3">
                {tier.features.map((feature, index) => (
                  <li key={index} className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5 shrink-0" />
                    <span className="text-muted-foreground">{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
            <CardFooter>
              <Button className="w-full" variant={tier.isPopular ? 'default' : 'outline'}>
                {tier.cta}
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
}
