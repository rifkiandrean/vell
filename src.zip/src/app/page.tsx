

import { Mountain, Utensils, Laptop, Heart } from 'lucide-react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { collection, doc, getDoc, getDocs, orderBy, query } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import type { LandingPageContent, HeroSlide, CompanyInfo } from '@/lib/types';
import Image from 'next/image';
import { HeroSlideshow } from '@/components/HeroSlideshow';
import { ChatWidget } from '@/components/ChatWidget';


// Function to fetch landing page content from Firestore
async function getLandingPageContent(): Promise<LandingPageContent> {
  try {
    const docRef = doc(db, "settings", "landingPage");
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return docSnap.data() as LandingPageContent;
    }
  } catch (error) {
    console.error("Error fetching landing page content:", error);
  }
  // Return default content if fetch fails or doc doesn't exist
  return {
    brandName: "VELL",
    featuresSubtitle: "Dari pesanan di meja hingga laporan keuangan, sistem kami mencakup setiap aspek operasional restoran Anda.",
    portfolioSubtitle: "Lihat bagaimana kami telah membantu bisnis seperti milik Anda untuk berkembang.",
    portfolioImageUrl1: "https://picsum.photos/seed/badia-kopi/600/400",
    portfolioImageUrl2: "https://picsum.photos/seed/wedding-invitation/600/400",
  };
}

async function getHeroSlides(): Promise<HeroSlide[]> {
    try {
        const q = query(collection(db, "heroSlides"), orderBy("order", "asc"));
        const querySnapshot = await getDocs(q);
        if (!querySnapshot.empty) {
            return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as HeroSlide));
        }
    } catch (error) {
        console.error("Error fetching hero slides:", error);
    }
    // Return default slides if fetch fails or collection is empty
    return [
        {
            id: 'default-1',
            title: "Elektronik Restoran Sistem Modern untuk Bisnis Anda",
            subtitle: "VELL menyediakan solusi lengkap dari Point-of-Sale (POS), manajemen inventaris, hingga analitik penjualan untuk membawa restoran Anda ke level berikutnya.",
            imageUrl: "https://picsum.photos/seed/restaurant-system/1200/800",
            imageHint: "restaurant system",
            order: 0,
        },
        {
            id: 'default-2',
            title: "Manajemen Kafe Menjadi Mudah",
            subtitle: "Aplikasi manajemen kafe lengkap dengan pemesanan via QR, sistem kasir, monitor dapur, dan panel admin untuk manajemen stok, menu, serta laporan keuangan.",
            imageUrl: "https://picsum.photos/seed/badia-kopi/1200/800",
            imageHint: "coffee shop",
            order: 1,
        },
    ];
}

async function getCompanyInfo(): Promise<CompanyInfo> {
    try {
        const docRef = doc(db, "settings", "companyInfo");
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
            return docSnap.data() as CompanyInfo;
        }
    } catch (error) {
        console.error("Error fetching company info:", error);
    }
    return { companyName: 'VELL' };
}


// Replicated on server-side to avoid client/server mismatch error.
const transformGoogleDriveUrl = (url: string): string => {
    if (!url || !url.includes('drive.google.com')) {
        return url;
    }
    const match = url.match(/file\/d\/([^/]+)/);
    if (match && match[1]) {
        return `https://drive.google.com/uc?export=view&id=${match[1]}`;
    }
    return url;
};


export default async function VellLandingPage() {
  const content = await getLandingPageContent();
  const heroSlidesData = await getHeroSlides();
  const companyInfo = await getCompanyInfo();

  const heroSlides = heroSlidesData.map(slide => ({
    ...slide,
    imageUrl: transformGoogleDriveUrl(slide.imageUrl),
  }));

  const portfolioImageUrl1 = content.portfolioImageUrl1 ? transformGoogleDriveUrl(content.portfolioImageUrl1) : "https://picsum.photos/seed/badia-kopi/600/400";
  const portfolioImageUrl2 = content.portfolioImageUrl2 ? transformGoogleDriveUrl(content.portfolioImageUrl2) : "https://picsum.photos/seed/wedding-invitation/600/400";
  const ersLogoUrl = companyInfo.ersLogoUrl ? transformGoogleDriveUrl(companyInfo.ersLogoUrl) : null;


  return (
    <div className="flex flex-col min-h-screen bg-background">
      <header className="px-4 lg:px-6 h-16 flex items-center bg-background border-b sticky top-0 z-50">
        <Link href="#" className="flex items-center justify-center gap-2" prefetch={false}>
          {ersLogoUrl ? (
            <Image src={ersLogoUrl} alt="VELL Logo" width={24} height={24} className="h-6 w-6 object-contain" />
          ) : (
            <Mountain className="h-6 w-6 text-primary" />
          )}
          <span className="text-xl font-bold tracking-tight text-primary">{content.brandName || "VELL"}</span>
        </Link>
        <nav className="ml-auto flex items-center gap-4 sm:gap-6">
          <Link href="#features" className="text-sm font-medium text-muted-foreground transition-colors hover:text-primary" prefetch={false}>
            Fitur
          </Link>
          <Link href="#portfolio" className="text-sm font-medium text-muted-foreground transition-colors hover:text-primary" prefetch={false}>
            Portofolio
          </Link>
          <Link href="/paket" className="text-sm font-medium text-muted-foreground transition-colors hover:text-primary" prefetch={false}>
            Paket
          </Link>
          <Link href="/blog" className="text-sm font-medium text-muted-foreground transition-colors hover:text-primary" prefetch={false}>
            Blog
          </Link>
          <Link href="#kontak" className="text-sm font-medium text-muted-foreground transition-colors hover:text-primary" prefetch={false}>
            Kontak
          </Link>
          <Link href="/admin/login" prefetch={false}>
             <Button>Login</Button>
          </Link>
        </nav>
      </header>
      <main className="flex-1">
        <section className="w-full relative">
            <HeroSlideshow slides={heroSlides} />
        </section>
        <section id="features" className="w-full py-12 md:py-24 lg:py-32 bg-background">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <div className="inline-block rounded-lg bg-muted px-3 py-1 text-sm">Fitur Utama</div>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Solusi Lengkap untuk Semua Kebutuhan</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  {content.featuresSubtitle}
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl items-start gap-8 py-12 sm:grid-cols-2 lg:grid-cols-3 lg:gap-12">
              <div className="grid gap-2 text-center p-6 rounded-lg transition-all hover:bg-muted/50 hover:shadow-lg">
                <Utensils className="h-10 w-10 mx-auto text-primary" />
                <h3 className="text-xl font-bold">Manajemen Pesanan & POS</h3>
                <p className="text-muted-foreground">Sistem kasir yang intuitif, terintegrasi dengan manajemen meja, dapur, dan pelayan secara real-time.</p>
              </div>
              <div className="grid gap-2 text-center p-6 rounded-lg transition-all hover:bg-muted/50 hover:shadow-lg">
                <Laptop className="h-10 w-10 mx-auto text-primary" />
                <h3 className="text-xl font-bold">Admin Panel Komprehensif</h3>
                <p className="text-muted-foreground">Kelola menu, inventaris, vendor, dan keuangan dengan analitik mendalam untuk pengambilan keputusan.</p>
              </div>
              <div className="grid gap-2 text-center p-6 rounded-lg transition-all hover:bg-muted/50 hover:shadow-lg">
                <Mountain className="h-10 w-10 mx-auto text-primary" />
                <h3 className="text-xl font-bold">Skalabilitas & Kustomisasi</h3>
                <p className="text-muted-foreground">Mendukung satu atau banyak cabang. Sistem dapat disesuaikan dengan branding dan kebutuhan unik bisnis Anda.</p>
              </div>
            </div>
          </div>
        </section>
        <section id="portfolio" className="w-full py-12 md:py-24 lg:py-32 bg-muted">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Portofolio Kami</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  {content.portfolioSubtitle}
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl items-center gap-8 py-12 lg:grid-cols-2 lg:gap-16">
              <div className="flex flex-col justify-center space-y-4">
                <div className="grid gap-2">
                  <h3 className="text-2xl font-bold flex items-center gap-2"><Utensils className="h-6 w-6"/>BADIA KOPI</h3>
                  <p className="text-muted-foreground">
                    Aplikasi manajemen kafe lengkap dengan pemesanan via QR, sistem kasir, monitor dapur, dan panel admin untuk manajemen stok, menu, serta laporan keuangan.
                  </p>
                  <Link href="/cafe" prefetch={false} className="mt-2">
                    <Button variant="outline">Lihat Demo</Button>
                  </Link>
                </div>
              </div>
              <img
                src={portfolioImageUrl1}
                width="600"
                height="400"
                alt="BADIA KOPI"
                className="mx-auto aspect-video overflow-hidden rounded-xl object-cover object-center sm:w-full shadow-lg"
                data-ai-hint="coffee shop"
              />
            </div>
            <div className="mx-auto grid max-w-5xl items-center gap-8 py-12 lg:grid-cols-2 lg:gap-16">
               <img
                src={portfolioImageUrl2}
                width="600"
                height="400"
                alt="Undangan Pernikahan Digital"
                className="mx-auto aspect-video overflow-hidden rounded-xl object-cover object-center sm:w-full shadow-lg lg:order-last"
                data-ai-hint="wedding invitation"
              />
              <div className="flex flex-col justify-center space-y-4">
                <div className="grid gap-2">
                  <h3 className="text-2xl font-bold flex items-center gap-2"><Heart className="h-6 w-6"/>Undangan Pernikahan Digital</h3>
                  <p className="text-muted-foreground">
                    Sistem undangan pernikahan digital modern dan interaktif. Fitur termasuk detail acara, galeri foto, cerita cinta, buku tamu digital, dan konfirmasi kehadiran (RSVP).
                  </p>
                  <Link href="/upd/hani" prefetch={false} className="mt-2">
                    <Button variant="outline">Lihat Contoh</Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer id="kontak" className="flex flex-col gap-2 sm:flex-row py-6 w-full shrink-0 items-center px-4 md:px-6 border-t">
        <p className="text-xs text-muted-foreground">&copy; 2024 {content.brandName || "VELL"}. Semua Hak Cipta Dilindungi.</p>
        <nav className="sm:ml-auto flex gap-4 sm:gap-6">
          <Link href="#" className="text-xs hover:underline underline-offset-4" prefetch={false}>
            Syarat & Ketentuan
          </Link>
          <Link href="#" className="text-xs hover:underline underline-offset-4" prefetch={false}>
            Kebijakan Privasi
          </Link>
        </nav>
      </footer>
      <ChatWidget />
    </div>
  );
}
