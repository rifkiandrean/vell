
import type { Metadata } from 'next';
import '../../../../globals.css';

export const metadata: Metadata = {
  title: 'Kasir | VELL ERS',
  description: 'Sistem Kasir (Point of Sale) untuk ERS.',
};

export default function CashierLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
