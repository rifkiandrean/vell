
'use client';

import { useState, useRef, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Music, Pause } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface AudioPlayerProps {
  src: string;
  isInvitationOpened: boolean;
}

export function AudioPlayer({ src, isInvitationOpened }: AudioPlayerProps) {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isReadyToPlay, setIsReadyToPlay] = useState(false);
  const { toast } = useToast();

  // Initialize Audio element on client
  useEffect(() => {
    audioRef.current = new Audio(src);
    audioRef.current.loop = true;
    
    const handleCanPlay = () => setIsReadyToPlay(true);
    const handleError = (e: Event) => {
        console.error("Audio Error:", e);
        toast({
            title: "Gagal Memuat Musik",
            description: "Pastikan URL musik adalah link langsung ke file MP3.",
            variant: "destructive"
        });
    };

    const audio = audioRef.current;
    audio.addEventListener('canplay', handleCanPlay);
    audio.addEventListener('error', handleError);
    
    return () => {
        audio.removeEventListener('canplay', handleCanPlay);
        audio.removeEventListener('error', handleError);
        audio.pause();
        audio.src = '';
    };
  }, [src, toast]);

  // Effect to auto-play when invitation is opened
  useEffect(() => {
    if (isInvitationOpened && isReadyToPlay) {
      audioRef.current?.play()
        .then(() => setIsPlaying(true))
        .catch(e => console.error("Autoplay failed:", e));
    }
  }, [isInvitationOpened, isReadyToPlay]);

  const toggleMusic = useCallback(() => {
    if (!audioRef.current || !isReadyToPlay) {
        toast({ title: "Musik Belum Siap", description: "Audio sedang dimuat atau gagal dimuat."});
        return;
    };

    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play().catch(e => console.error("Manual play failed:", e));
    }
    setIsPlaying(!isPlaying);
  }, [isPlaying, isReadyToPlay, toast]);


  if (!src) return null;

  return (
    <div className="fixed bottom-4 right-4 z-40">
        <Button onClick={toggleMusic} size="icon" className="rounded-full shadow-lg" disabled={!isReadyToPlay}>
            {isPlaying ? <Pause /> : <Music />}
        </Button>
    </div>
  );
}

