'use client';

import { useState, useRef, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { ScrollArea } from './ui/scroll-area';
import { MessageCircle, Send, X, Bot, User } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { chatAgent } from '@/ai/flows/chat-agent';
import type { ChatAgentInput } from '@/lib/types/chat-agent';

type Message = {
  role: 'user' | 'model';
  text: string;
};

export function ChatWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollAreaRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      setMessages([
        {
          role: 'model',
          text: 'Halo! Saya asisten AI dari VELL. Ada yang bisa saya bantu terkait produk kami?',
        },
      ]);
    }
  }, [isOpen]);

  useEffect(() => {
    // Scroll to bottom when new messages are added
    if (scrollAreaRef.current) {
        const viewport = scrollAreaRef.current.querySelector('[data-radix-scroll-area-viewport]');
        if (viewport) {
            viewport.scrollTop = viewport.scrollHeight;
        }
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage: Message = { role: 'user', text: input };
    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
        const chatHistory = messages.map(msg => ({
            role: msg.role,
            content: [{ text: msg.text }],
        }));

      const response = await chatAgent({ message: input, history: chatHistory });
      
      const modelMessage: Message = { role: 'model', text: response };
      setMessages((prev) => [...prev, modelMessage]);

    } catch (error) {
      console.error('Chat error:', error);
      const errorMessage: Message = {
        role: 'model',
        text: 'Maaf, terjadi kesalahan. Silakan coba lagi nanti.',
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <div className="fixed bottom-5 right-5 z-50">
        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 50 }}
              transition={{ duration: 0.3 }}
            >
              <Card className="w-80 h-[450px] flex flex-col shadow-xl">
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Bot /> Asisten VELL
                  </CardTitle>
                  <Button variant="ghost" size="icon" onClick={() => setIsOpen(false)}>
                    <X className="h-4 w-4" />
                  </Button>
                </CardHeader>
                <CardContent className="flex-1 flex flex-col p-0">
                  <ScrollArea className="flex-1 p-4" ref={scrollAreaRef}>
                    <div className="space-y-4">
                      {messages.map((msg, index) => (
                        <div
                          key={index}
                          className={cn(
                            'flex gap-2 text-sm',
                            msg.role === 'user' ? 'justify-end' : 'justify-start'
                          )}
                        >
                           {msg.role === 'model' && <Bot className="h-5 w-5 text-primary shrink-0"/>}
                          <div
                            className={cn(
                              'max-w-[80%] rounded-lg px-3 py-2',
                              msg.role === 'user'
                                ? 'bg-primary text-primary-foreground'
                                : 'bg-muted'
                            )}
                          >
                            {msg.text}
                          </div>
                           {msg.role === 'user' && <User className="h-5 w-5 text-muted-foreground shrink-0"/>}
                        </div>
                      ))}
                      {isLoading && (
                        <div className="flex justify-start gap-2">
                          <Bot className="h-5 w-5 text-primary shrink-0"/>
                          <div className="bg-muted rounded-lg px-3 py-2 text-sm">
                            <span className="animate-pulse">...</span>
                          </div>
                        </div>
                      )}
                    </div>
                  </ScrollArea>
                  <div className="p-4 border-t">
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        handleSend();
                      }}
                      className="flex gap-2"
                    >
                      <Input
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        placeholder="Tulis pesan..."
                        disabled={isLoading}
                      />
                      <Button type="submit" size="icon" disabled={isLoading}>
                        <Send className="h-4 w-4" />
                      </Button>
                    </form>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.5, duration: 0.3 }}
        >
          <Button
            size="icon"
            className="w-16 h-16 rounded-full shadow-lg"
            onClick={() => setIsOpen(!isOpen)}
            aria-label="Toggle chat"
          >
            {isOpen ? <X className="h-8 w-8" /> : <MessageCircle className="h-8 w-8" />}
          </Button>
        </motion.div>
      </div>
    </>
  );
}
