
'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Heart } from 'lucide-react';
import { doc, onSnapshot, runTransaction } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';

interface LikeButtonProps {
  postId: string;
  initialLikes: number;
}

export function LikeButton({ postId, initialLikes }: LikeButtonProps) {
  const [likes, setLikes] = useState(initialLikes);
  const [isLiked, setIsLiked] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    // Check local storage to see if the user has already liked this post
    const likedPosts = JSON.parse(localStorage.getItem('likedPosts') || '[]');
    if (likedPosts.includes(postId)) {
      setIsLiked(true);
    }

    // Listen for real-time updates on likes
    const unsub = onSnapshot(doc(db, 'posts', postId), (docSnap) => {
      if (docSnap.exists()) {
        setLikes(docSnap.data().likes || 0);
      }
    });

    return () => unsub();
  }, [postId]);

  const handleLike = async () => {
    if (isProcessing) return;
    
    // Optimistic UI update
    if (isLiked) {
      // Unlike
      setLikes(l => l - 1);
      setIsLiked(false);
      const likedPosts = JSON.parse(localStorage.getItem('likedPosts') || '[]').filter((id: string) => id !== postId);
      localStorage.setItem('likedPosts', JSON.stringify(likedPosts));
    } else {
      // Like
      setLikes(l => l + 1);
      setIsLiked(true);
      const likedPosts = JSON.parse(localStorage.getItem('likedPosts') || '[]');
      localStorage.setItem('likedPosts', JSON.stringify([...likedPosts, postId]));
    }
    
    setIsProcessing(true);

    try {
      await runTransaction(db, async (transaction) => {
        const postRef = doc(db, 'posts', postId);
        const postDoc = await transaction.get(postRef);
        if (!postDoc.exists()) {
          throw new Error("Post does not exist!");
        }

        const currentLikes = postDoc.data().likes || 0;
        const newLikes = isLiked ? Math.max(0, currentLikes - 1) : currentLikes + 1;
        transaction.update(postRef, { likes: newLikes });
      });
    } catch (error) {
      console.error("Failed to update likes:", error);
      // Revert optimistic update on error
      setLikes(prevLikes => isLiked ? prevLikes + 1 : prevLikes - 1);
      setIsLiked(prevIsLiked => !prevIsLiked);
      const likedPosts = isLiked
        ? [...JSON.parse(localStorage.getItem('likedPosts') || '[]'), postId]
        : JSON.parse(localStorage.getItem('likedPosts') || '[]').filter((id: string) => id !== postId);
      localStorage.setItem('likedPosts', JSON.stringify(likedPosts));

      toast({
        variant: "destructive",
        title: "Gagal",
        description: "Gagal memberikan suka. Coba lagi nanti.",
      });
    } finally {
        setIsProcessing(false);
    }
  };

  return (
    <Button onClick={handleLike} variant="outline" size="sm" className="gap-2" disabled={isProcessing}>
      <Heart className={cn("h-4 w-4", isLiked && "fill-red-500 text-red-500")} />
      <span>{likes}</span>
    </Button>
  );
}
