
'use client';

import Image from 'next/image';
import Link from 'next/link';
import { Carousel, CarouselContent, CarouselItem } from '@/components/ui/carousel';
import Autoplay from 'embla-carousel-autoplay';

type Slide = {
  title: string;
  subtitle: string;
  imageUrl: string;
  imageHint: string;
};

interface HeroSlideshowProps {
  slides: Slide[];
}

export function HeroSlideshow({ slides }: HeroSlideshowProps) {
  return (
    <Carousel
      opts={{ loop: true }}
      plugins={[Autoplay({ delay: 5000, stopOnInteraction: false })]}
    >
      <CarouselContent>
        {slides.map((slide, index) => (
          <CarouselItem key={index}>
            <div className="relative w-full h-[60vh] md:h-[70vh]">
              <Image
                src={slide.imageUrl}
                alt={slide.title}
                fill
                className="object-cover brightness-50"
                data-ai-hint={slide.imageHint}
                priority={index === 0} // Prioritize loading the first image
              />
              <div className="absolute inset-0 flex flex-col justify-center items-center text-center text-white p-4">
                <div className="max-w-3xl">
                  <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none text-white drop-shadow-md">
                    {slide.title}
                  </h1>
                  <p className="max-w-[700px] text-gray-200 md:text-xl mt-4 drop-shadow-md">
                    {slide.subtitle}
                  </p>
                  <div className="flex flex-col gap-2 min-[400px]:flex-row justify-center mt-8">
                    <Link
                      href="#features"
                      className="inline-flex h-10 items-center justify-center rounded-md bg-primary px-8 text-sm font-medium text-primary-foreground shadow transition-colors hover:bg-primary/90 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50"
                      prefetch={false}
                    >
                      Pelajari Fitur
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </CarouselItem>
        ))}
      </CarouselContent>
    </Carousel>
  );
}