
"use client";

import { useEffect, useState } from "react";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { db } from "@/lib/firebase";
import { collection, doc, getDoc, setDoc, onSnapshot, query, orderBy, deleteDoc, writeBatch } from "firebase/firestore";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/hooks/use-toast";
import type { LandingPageContent, HeroSlide } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from "@/components/ui/form";
import { logActivity } from "@/lib/activity-log";
import { Separator } from "../ui/separator";
import { PlusCircle, Trash2 } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

const landingPageSchema = z.object({
  websiteTitle: z.string().optional(),
  brandName: z.string().optional(),
  featuresSubtitle: z.string().optional(),
  portfolioSubtitle: z.string().optional(),
  portfolioImageUrl1: z.string().url("URL gambar tidak valid").or(z.literal('')).optional(),
  portfolioImageUrl2: z.string().url("URL gambar tidak valid").or(z.literal('')).optional(),
});

const heroSlideSchema = z.object({
  title: z.string().min(1, "Judul wajib diisi"),
  subtitle: z.string().min(1, "Subjudul wajib diisi"),
  imageUrl: z.string().url("URL gambar tidak valid"),
  imageHint: z.string().optional(),
});

const slidesSchema = z.object({
  slides: z.array(heroSlideSchema),
});


type LandingPageFormValues = z.infer<typeof landingPageSchema>;
type SlidesFormValues = z.infer<typeof slidesSchema>;

export function LandingPageSettings() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [slides, setSlides] = useState<HeroSlide[]>([]);

  const landingPageForm = useForm<LandingPageFormValues>({
    resolver: zodResolver(landingPageSchema),
    defaultValues: {
      websiteTitle: "",
      brandName: "",
      featuresSubtitle: "",
      portfolioSubtitle: "",
      portfolioImageUrl1: "",
      portfolioImageUrl2: "",
    },
  });

  const slidesForm = useForm<SlidesFormValues>({
    resolver: zodResolver(slidesSchema),
    defaultValues: { slides: [] },
  });

  const { fields, append, remove } = useFieldArray({
    control: slidesForm.control,
    name: "slides",
  });

  useEffect(() => {
    const unsubContent = onSnapshot(doc(db, "settings", "landingPage"), (docSnap) => {
      if (docSnap.exists()) {
        landingPageForm.reset(docSnap.data() as LandingPageContent);
      }
    });
    
    const q = query(collection(db, "heroSlides"), orderBy("order", "asc"));
    const unsubSlides = onSnapshot(q, (snapshot) => {
      const fetchedSlides = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as HeroSlide));
      setSlides(fetchedSlides);
      slidesForm.reset({ slides: fetchedSlides });
    });

    return () => {
        unsubContent();
        unsubSlides();
    };
  }, [landingPageForm, slidesForm]);

  const onLandingPageSubmit = async (data: LandingPageFormValues) => {
    try {
      const docRef = doc(db, "settings", "landingPage");
      await setDoc(docRef, data, { merge: true });
      logActivity(user, "Memperbarui konten landing page VELL.");
      toast({
        title: "Pengaturan Disimpan",
        description: "Konten landing page telah diperbarui.",
      });
    } catch (error) {
      console.error("Gagal menyimpan pengaturan:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Gagal menyimpan pengaturan.",
      });
    }
  };

  const onSlidesSubmit = async (data: SlidesFormValues) => {
    try {
        const batch = writeBatch(db);
        data.slides.forEach((slide, index) => {
            const slideId = slides[index]?.id || doc(collection(db, "heroSlides")).id;
            const docRef = doc(db, "heroSlides", slideId);
            batch.set(docRef, { ...slide, order: index });
        });
        await batch.commit();
        logActivity(user, `Memperbarui ${data.slides.length} slide di hero section.`);
        toast({
            title: "Slideshow Disimpan",
            description: "Pengaturan slideshow telah diperbarui.",
        });
    } catch (error) {
        console.error("Gagal menyimpan slideshow:", error);
        toast({
            variant: "destructive",
            title: "Error",
            description: "Gagal menyimpan pengaturan slideshow.",
        });
    }
  };

  const handleRemoveSlide = async (index: number) => {
    const slideToRemove = slides[index];
    if (slideToRemove) {
      try {
        await deleteDoc(doc(db, "heroSlides", slideToRemove.id));
        remove(index);
        logActivity(user, `Menghapus slide: ${slideToRemove.title}`);
        toast({
          title: "Slide Dihapus",
          description: "Slide telah berhasil dihapus.",
        });
      } catch (error) {
        toast({
          variant: "destructive",
          title: "Error",
          description: "Gagal menghapus slide.",
        });
      }
    } else {
        remove(index);
    }
  };

  return (
    <div className="space-y-8">
      <Form {...landingPageForm}>
        <form onSubmit={landingPageForm.handleSubmit(onLandingPageSubmit)} className="space-y-8">
          <Card>
            <CardHeader>
              <CardTitle>Branding &amp; SEO</CardTitle>
              <CardDescription>Atur judul website dan nama brand.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <FormField
                control={landingPageForm.control}
                name="websiteTitle"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Judul Website (Tab Browser)</FormLabel>
                    <FormControl>
                      <Input placeholder="VELL - Elektronik Restoran Sistem" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={landingPageForm.control}
                name="brandName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nama Brand di Header</FormLabel>
                    <FormControl>
                      <Input placeholder="VELL" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Bagian Fitur &amp; Portofolio</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <FormField
                control={landingPageForm.control}
                name="featuresSubtitle"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Deskripsi Bagian Fitur</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Dari pesanan di meja hingga laporan keuangan..." {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={landingPageForm.control}
                name="portfolioSubtitle"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Deskripsi Bagian Portofolio</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Lihat bagaimana kami telah membantu..." {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={landingPageForm.control}
                name="portfolioImageUrl1"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>URL Gambar Portofolio 1 (cth: Badia Kopi)</FormLabel>
                    <FormControl>
                      <Input placeholder="https://images.unsplash.com/..." {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={landingPageForm.control}
                name="portfolioImageUrl2"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>URL Gambar Portofolio 2 (cth: Undangan)</FormLabel>
                    <FormControl>
                      <Input placeholder="https://images.unsplash.com/..." {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          <Button type="submit" disabled={landingPageForm.formState.isSubmitting}>
            {landingPageForm.formState.isSubmitting ? 'Menyimpan...' : 'Simpan Pengaturan Landing Page'}
          </Button>
        </form>
      </Form>
      
      <Separator />

      <Form {...slidesForm}>
        <form onSubmit={slidesForm.handleSubmit(onSlidesSubmit)} className="space-y-8">
            <Card>
                <CardHeader>
                    <CardTitle>Pengaturan Slideshow</CardTitle>
                    <CardDescription>Atur slide yang akan ditampilkan di bagian atas halaman utama.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    {fields.map((field, index) => (
                        <div key={field.id} className="p-4 border rounded-lg space-y-4 relative">
                             <h4 className="font-semibold">Slide {index + 1}</h4>
                            <FormField
                                control={slidesForm.control}
                                name={`slides.${index}.title`}
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Judul</FormLabel>
                                        <FormControl><Input {...field} /></FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={slidesForm.control}
                                name={`slides.${index}.subtitle`}
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Subjudul</FormLabel>
                                        <FormControl><Textarea {...field} /></FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={slidesForm.control}
                                name={`slides.${index}.imageUrl`}
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>URL Gambar</FormLabel>
                                        <FormControl><Input {...field} /></FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={slidesForm.control}
                                name={`slides.${index}.imageHint`}
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Petunjuk Gambar (AI Hint)</FormLabel>
                                        <FormControl><Input {...field} /></FormControl>
                                        <FormDescription>Dua kata kunci untuk pencarian gambar AI, dipisahkan spasi.</FormDescription>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                             <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button type="button" variant="destructive" size="icon" className="absolute top-2 right-2">
                                      <Trash2 className="h-4 w-4" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                    <AlertDialogHeader>
                                        <AlertDialogTitle>Hapus Slide Ini?</AlertDialogTitle>
                                        <AlertDialogDescription>Tindakan ini akan menghapus slide secara permanen.</AlertDialogDescription>
                                    </AlertDialogHeader>
                                    <AlertDialogFooter>
                                        <AlertDialogCancel>Batal</AlertDialogCancel>
                                        <AlertDialogAction onClick={() => handleRemoveSlide(index)}>Hapus</AlertDialogAction>
                                    </AlertDialogFooter>
                                </AlertDialogContent>
                            </AlertDialog>
                        </div>
                    ))}
                     <Button 
                        type="button" 
                        variant="outline" 
                        onClick={() => append({ title: '', subtitle: '', imageUrl: '', imageHint: '' })}>
                        <PlusCircle className="mr-2 h-4 w-4" /> Tambah Slide Baru
                    </Button>
                </CardContent>
            </Card>
            <Button type="submit" disabled={slidesForm.formState.isSubmitting}>
              {slidesForm.formState.isSubmitting ? 'Menyimpan...' : 'Simpan Pengaturan Slideshow'}
            </Button>
        </form>
      </Form>
    </div>
  );
}
