
"use client";

import { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { db } from '@/lib/firebase';
import { doc, getDoc, setDoc, addDoc, collection, serverTimestamp } from 'firebase/firestore';
import type { Post } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from '@/components/ui/form';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { logActivity } from '@/lib/activity-log';

const postSchema = z.object({
  title: z.string().min(1, "Judul wajib diisi"),
  slug: z.string().min(1, "Slug wajib diisi").regex(/^[a-z0-9-]+$/, "Slug hanya boleh berisi huruf kecil, angka, dan tanda hubung"),
  content: z.string().min(1, "Konten tidak boleh kosong"),
  featuredImageUrl: z.string().url("URL gambar tidak valid").optional().or(z.literal('')),
  status: z.enum(['draft', 'published'], { required_error: "Status wajib dipilih" }),
});

type PostFormValues = z.infer<typeof postSchema>;

interface PostEditorProps {
  postId?: string;
}

export function PostEditor({ postId }: PostEditorProps) {
  const isEditMode = !!postId;
  const router = useRouter();
  const { user } = useAuth();
  const { toast } = useToast();

  const form = useForm<PostFormValues>({
    resolver: zodResolver(postSchema),
    defaultValues: {
      title: '',
      slug: '',
      content: '',
      featuredImageUrl: '',
      status: 'draft',
    },
  });

  const watchedTitle = form.watch('title');
  useEffect(() => {
      const slug = watchedTitle.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
      if (form.getValues('slug') !== slug) {
        form.setValue('slug', slug, { shouldValidate: true });
      }
  }, [watchedTitle, form]);


  useEffect(() => {
    if (isEditMode && postId) {
      const fetchPost = async () => {
        const docRef = doc(db, 'posts', postId);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const postData = docSnap.data() as Post;
          form.reset({
            title: postData.title,
            slug: postData.slug,
            content: postData.content,
            featuredImageUrl: postData.featuredImageUrl || '',
            status: postData.status,
          });
        } else {
          toast({ variant: 'destructive', title: 'Error', description: 'Postingan tidak ditemukan.' });
          router.push('/admin/posts');
        }
      };
      fetchPost();
    }
  }, [isEditMode, postId, router, toast, form]);

  const onSubmit = async (data: PostFormValues) => {
    if (!user) {
      toast({ variant: 'destructive', title: 'Error', description: 'Anda harus login untuk membuat postingan.' });
      return;
    }
    
    const postData = {
      ...data,
      authorId: user.uid,
      authorName: user.displayName || user.email || 'Admin',
      updatedAt: serverTimestamp(),
    };

    try {
      if (isEditMode && postId) {
        const docRef = doc(db, 'posts', postId);
        await setDoc(docRef, { ...postData, createdAt: (await getDoc(docRef)).data()?.createdAt || serverTimestamp() }, { merge: true });
        logActivity(user, `Mengubah postingan: ${data.title}`);
        toast({ title: 'Sukses', description: 'Postingan berhasil diperbarui.' });
      } else {
        await addDoc(collection(db, 'posts'), { ...postData, createdAt: serverTimestamp() });
        logActivity(user, `Membuat postingan baru: ${data.title}`);
        toast({ title: 'Sukses', description: 'Postingan baru berhasil dibuat.' });
      }
      router.push('/admin/posts');
    } catch (error) {
      console.error("Gagal menyimpan postingan:", error);
      toast({ variant: 'destructive', title: 'Error', description: 'Gagal menyimpan postingan.' });
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)}>
        <Card>
          <CardHeader>
            <CardTitle>{isEditMode ? 'Ubah Postingan' : 'Buat Postingan Baru'}</CardTitle>
            <CardDescription>Gunakan Markdown untuk memformat konten Anda.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Judul Postingan</FormLabel>
                  <FormControl><Input placeholder="Judul yang menarik..." {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="slug"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Slug (URL)</FormLabel>
                  <FormControl><Input placeholder="judul-postingan-unik" {...field} /></FormControl>
                  <FormDescription>Ini akan menjadi bagian dari URL postingan Anda.</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="featuredImageUrl"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>URL Gambar Utama (Opsional)</FormLabel>
                  <FormControl><Input placeholder="https://..." {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="content"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Konten</FormLabel>
                  <FormControl><Textarea placeholder="Tulis cerita Anda di sini... Mendukung Markdown." {...field} rows={15} /></FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="status"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Status</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl><SelectTrigger><SelectValue placeholder="Pilih status" /></SelectTrigger></FormControl>
                    <SelectContent>
                      <SelectItem value="draft">Draf</SelectItem>
                      <SelectItem value="published">Terbitkan</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </CardContent>
          <CardFooter className="flex justify-end">
            <Button type="submit" disabled={form.formState.isSubmitting}>
              {form.formState.isSubmitting ? 'Menyimpan...' : 'Simpan Postingan'}
            </Button>
          </CardFooter>
        </Card>
      </form>
    </Form>
  );
}
