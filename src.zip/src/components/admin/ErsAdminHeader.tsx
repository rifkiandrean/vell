
"use client";

import Link from 'next/link';
import { Button } from '../ui/button';
import { LogOut, User, Lock, Presentation, FileText } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from 'next/navigation';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator, DropdownMenuLabel } from '../ui/dropdown-menu';
import Image from 'next/image';
import { logActivity } from '@/lib/activity-log';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from '@/components/ui/dialog';
import { ProfileManagement } from './ProfileManagement';
import { Mountain } from 'lucide-react';


export function ErsAdminHeader() {
  const { user, logout, ersLogoUrl, websiteVersion } = useAuth();
  const router = useRouter();

  const handleLogout = async () => {
    if (user) {
      logActivity(user, 'Logout dari sistem ERS.');
    }
    await logout();
    router.push('/admin/login');
  };
  
  return (
    <Dialog>
      <header className="border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Link href="/" className="flex items-center gap-2 ml-2">
              {ersLogoUrl ? (
                  <Image src={ersLogoUrl} alt="VELL logo" width={32} height={32} className="h-8 w-8 object-contain" />
              ) : (
                  <Mountain className="h-8 w-8 text-primary" />
              )}
              <div className="flex items-baseline gap-2">
                  <h1 className="text-2xl font-bold tracking-tighter">VELL</h1>
              </div>
            </Link>
          </div>

          <nav className="flex items-center gap-1 md:gap-2">
             <Button variant="ghost" asChild>
                <Link href="/admin/posts">
                    <FileText className="mr-2 h-4 w-4" />
                    Postingan
                </Link>
            </Button>
            <Button variant="ghost" asChild>
                <Link href="/admin/landing-page">
                    <Presentation className="mr-2 h-4 w-4" />
                    Halaman Utama
                </Link>
            </Button>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="icon">
                  <User className="h-4 w-4" />
                  <span className="sr-only">Profil</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-64">
                <DropdownMenuLabel>Profil Saya</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <div className="px-2 py-1.5 text-sm">
                  <p className="font-semibold">{user?.displayName || 'Nama Pengguna'}</p>
                  <p className="text-xs text-muted-foreground">{user?.email || 'email@pengguna.com'}</p>
                </div>
                <DropdownMenuSeparator />
                <DialogTrigger asChild>
                  <DropdownMenuItem onSelect={(e) => e.preventDefault()}>
                    <Lock className="mr-2 h-4 w-4" />
                    <span>Ubah Password</span>
                  </DropdownMenuItem>
                </DialogTrigger>
              </DropdownMenuContent>
            </DropdownMenu>

            <Button onClick={handleLogout} variant="outline" size="icon">
              <LogOut className="h-4 w-4" />
              <span className="sr-only">Logout</span>
            </Button>
          </nav>
        </div>
      </header>
      <DialogContent className="sm:max-w-[480px]">
        <DialogHeader>
          <DialogTitle>Ubah Password</DialogTitle>
          <DialogDescription>
            Ubah password Anda secara berkala untuk menjaga keamanan akun. Anda akan otomatis logout setelah berhasil.
          </DialogDescription>
        </DialogHeader>
        <ProfileManagement />
      </DialogContent>
    </Dialog>
  );
}
