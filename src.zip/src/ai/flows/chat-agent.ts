'use server';
/**
 * @fileOverview An AI flow to power a customer service chatbot.
 * - chatAgent - The main chat function.
 */

import { ai } from '@/ai/genkit';
import { googleAI } from '@genkit-ai/googleai';
import { z } from 'genkit';
import {
  ChatAgentInputSchema,
  type ChatAgentInput,
  ChatAgentOutputSchema,
  type ChatAgentOutput,
} from '@/lib/types/chat-agent';


export async function chatAgent(input: ChatAgentInput): Promise<ChatAgentOutput> {
  const result = await chatAgentFlow(input);
  return result;
}


const chatAgentFlow = ai.defineFlow(
  {
    name: 'chatAgentFlow',
    inputSchema: ChatAgentInputSchema,
    outputSchema: ChatAgentOutputSchema,
  },
  async (input) => {
    try {
      const llmResponse = await ai.generate({
        model: googleAI.model('gemini-1.5-pro-preview-0514'),
        history: input.history,
        prompt: input.message,
      });

      return llmResponse.text();
    } catch (error) {
      console.error("Error in chatAgentFlow:", error);
      return 'Maaf, terjadi masalah dengan layanan AI. Silakan coba lagi nanti.';
    }
  }
);
