import { z } from 'genkit';

const HistoryItemSchema = z.object({
  role: z.enum(['user', 'model']),
  content: z.array(z.object({ text: z.string() })),
});

export const ChatAgentInputSchema = z.object({
  message: z.string().describe("The user's current message."),
  history: z.array(HistoryItemSchema).describe('The chat history.'),
});
export type ChatAgentInput = z.infer<typeof ChatAgentInputSchema>;

export const ChatAgentOutputSchema = z
  .string()
  .describe('The AI response message.');
export type ChatAgentOutput = z.infer<typeof ChatAgentOutputSchema>;
